<?php $__env->startSection('main_content'); ?>
<div class="page-top">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>History Transaksi</h2>
            </div>
        </div>
    </div>
</div>
<div class="page-content">
    <div class="container">
        <div class="row cart">
            <div class="col-md-12">



                <div class="table-responsive">
                    <table class="table table-bordered table-cart" id="example1">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Order No</th>
                                <th>Payment Method</th>
                                <th>Payment Status</th>
                                <th>Booking Date</th>
                                <th>Paid Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($row->order_no); ?></td>
                                <td><?php echo e($row->payment_method); ?></td>
                                <td>
                                    <?php if($row->status == 'Pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                    <?php elseif($row->status == 'Completed'): ?>
                                    <span class="badge badge-success">Completed</span>
                                    <?php elseif($row->status == 'Cancel'): ?>
                                    <span class="badge badge-danger">Batal</span>
                                    <?php endif; ?>
                                <td><?php echo e($row->booking_date); ?></td>
                                <td><?php echo e($row->paid_amount); ?></td>
                                <td class="pt_10 pb_10">
                                    <?php if($row->payment_method == 'Midtrans'): ?>
                                    <a href="<?php echo e(route('transaksi_detail',$row->id)); ?>" class="btn btn-primary">Detail</a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('transaksi_detail_bank',$row->id)); ?>" class="btn btn-primary">Detail</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="checkout mb_20">
                    
                </div>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\14_Booking Hotel Laravel\resources\views/front/transaksi/transaksi.blade.php ENDPATH**/ ?>