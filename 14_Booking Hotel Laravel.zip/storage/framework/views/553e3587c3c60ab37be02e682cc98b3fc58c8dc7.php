<!-- All Javascripts -->
<script src="<?php echo e(asset('dist-front/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/select2.full.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/acmeticker.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/daterangepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/sticky_sidebar.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/jquery.meanmenu.js')); ?>"></script>
<script src="<?php echo e(asset('dist-front/js/iziToast.min.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\online_hotel_booking\resources\views/front/layout/scripts.blade.php ENDPATH**/ ?>