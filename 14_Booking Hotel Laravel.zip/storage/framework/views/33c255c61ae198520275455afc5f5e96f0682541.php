<!DOCTYPE html>
<html lang="en">
<head>
    <title>Email</title>
</head>
<body>
    <p><?php echo $body; ?></p>
</body>
</html><?php /**PATH D:\xampp\htdocs\online_hotel_booking\resources\views/email/email.blade.php ENDPATH**/ ?>